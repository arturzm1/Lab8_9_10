﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SD_DesignPatterns
{
    class Program
    {
        static void Main(string[] args)
        {
            
            var tripBuilder = new TripLaptopBuilder();
            var gamingBuilder = new GamingLaptopBuilder();
            var shopForYou = new BuyLaptop();
            shopForYou.SetLaptopBuilder(gamingBuilder);
            shopForYou.ConstructLaptop();
            Laptop laptop = shopForYou.GetLaptop();
            Console.WriteLine(laptop.ToString());
        }
    }
}
