﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SD_LAB_03.Models
{
    /// <summary>
    /// Угода про аренду квартири
    /// </summary>
    public class RentAgreement
    {
        public int Id { get; set; }
        public string ClientName { get; set; }
        public string Address { get; set; }
        public int LeaseTerm { get; set; }
        public decimal MonthlyPayment { get; set; }
    }
}
