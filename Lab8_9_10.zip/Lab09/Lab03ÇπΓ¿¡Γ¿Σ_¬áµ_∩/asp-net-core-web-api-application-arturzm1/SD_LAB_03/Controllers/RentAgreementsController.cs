﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SD_LAB_03.Models;

namespace SD_LAB_03.Controllers
{
    [Produces("application/json")]
    [Route("api/RentAgreements")]
    public class RentAgreementsController : Controller
    {
        private readonly LabDbContext _context;

        public RentAgreementsController(LabDbContext context)
        {
            _context = context;
        }

        // GET: api/RentAgreements
        [HttpGet]
        public IEnumerable<RentAgreement> GetRentAgreement()
        {
            return _context.RentAgreement;
        }

        // GET: api/RentAgreements/5
        [HttpGet("{id}")]
        public async Task<IActionResult> GetRentAgreement([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var rentAgreement = await _context.RentAgreement.SingleOrDefaultAsync(m => m.Id == id);

            if (rentAgreement == null)
            {
                return NotFound();
            }

            return Ok(rentAgreement);
        }

        // PUT: api/RentAgreements/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutRentAgreement([FromRoute] int id, [FromBody] RentAgreement rentAgreement)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != rentAgreement.Id)
            {
                return BadRequest();
            }

            _context.Entry(rentAgreement).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!RentAgreementExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/RentAgreements
        [HttpPost]
        public async Task<IActionResult> PostRentAgreement([FromBody] RentAgreement rentAgreement)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _context.RentAgreement.Add(rentAgreement);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetRentAgreement", new { id = rentAgreement.Id }, rentAgreement);
        }

        // DELETE: api/RentAgreements/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteRentAgreement([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var rentAgreement = await _context.RentAgreement.SingleOrDefaultAsync(m => m.Id == id);
            if (rentAgreement == null)
            {
                return NotFound();
            }

            _context.RentAgreement.Remove(rentAgreement);
            await _context.SaveChangesAsync();

            return Ok(rentAgreement);
        }

        private bool RentAgreementExists(int id)
        {
            return _context.RentAgreement.Any(e => e.Id == id);
        }
    }
}