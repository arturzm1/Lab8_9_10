using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SD_LAB_03.Models;

namespace SD_LAB_03.Controllers
{
    [Produces("application/json")]
    [Route("api/PessengerTrains")]
    public class PessengerTrainsController : Controller
    {
        private readonly LabDbContext _context;


        
        public PessengerTrainsController(LabDbContext context)
        {
            _context = context;
        }

        // GET: api/PassengerTrains
        [HttpGet]
        public IActionResult Index()
        {
            ViewBag.Countries=_context.PassengerTrains;
            return View();
        }

        public IEnumerable<PassengerTrains> GetPessengerTrains()
        {
            return _context.PassengerTrains;
        }

        // GET: api/PassengerTrains/5
        [HttpGet("{id}")]
        public async Task<IActionResult> GetPessengerTrains([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var passengerTrains = await _context.PassengerTrains.SingleOrDefaultAsync(m => m.Id == id);

            if (passengerTrains == null)
            {
                return NotFound();
            }

            return Ok(passengerTrains);
        }

        // PUT: api/PassengerTrains/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutPassengerTrains([FromRoute] int id, [FromBody] PassengerTrains passengerTrains)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != passengerTrains.Id)
            {
                return BadRequest();
            }

            _context.Entry(passengerTrains).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PassengerTrainsExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/RentAgreements
        [HttpPost]
        public async Task<IActionResult> PostPassengerTrains([FromBody] PassengerTrains passengerTrains)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _context.PassengerTrains.Add(passengerTrains);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetPassengerTrains", new { id = passengerTrains.Id }, passengerTrains);
        }

        // DELETE: api/RentAgreements/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeletePassengerTrains([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var passengerTrains = await _context.PassengerTrains.SingleOrDefaultAsync(m => m.Id == id);
            if (passengerTrains == null)
            {
                return NotFound();
            }

            _context.PassengerTrains.Remove(passengerTrains);
            await _context.SaveChangesAsync();

            return Ok(passengerTrains);
        }

        private bool PassengerTrainsExists(int id)
        {
            return _context.PassengerTrains.Any(e => e.Id == id);
        }
    }
}