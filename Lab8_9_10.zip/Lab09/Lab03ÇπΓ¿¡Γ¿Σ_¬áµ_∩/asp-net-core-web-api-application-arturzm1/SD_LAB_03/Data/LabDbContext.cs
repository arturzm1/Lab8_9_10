﻿using System;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace SD_LAB_03.Models
{
    public class LabDbContext : DbContext
    {
        public LabDbContext (DbContextOptions<LabDbContext> options)
            : base(options)
        {
        }

        public DbSet<RentAgreement> RentAgreement { get; set; }
        //new
        public DbSet<PassengerTrains> PassengerTrains{get;set;}
    }
}
