﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SD_Lab_06.Models
{
    /// <summary>
    /// Угода про аренду квартири
    /// </summary>
    public class RentAgreement : IValidatableObject
    {
        [Key]
        [Required]
        public int Id { get; set; }
        [Display(Name = "Прізвище та ім'я клієнта")]
        [StringLength(65, MinimumLength = 5, ErrorMessage = "Прізвище та ім'я клієнта має бути від 5 до 65 симв.")]
        public string ClientName { get; set; }
        [Display(Name = "Адреса")]
        [StringLength(65, MinimumLength = 5, ErrorMessage = "Адреса має бути від 5 до 65 симв.")]
        public string Address { get; set; }
        [Display(Name = "Термін аренди (міс.)")]
        [Range(3, 120, ErrorMessage = "Термін аренди від 3 до 120 міс.")]
        public int LeaseTerm { get; set; }
        [Display(Name = "Щомісячна плата")]
        [Range(1, 50000, ErrorMessage = "Термін аренди від 1 до 50000 грн.")]
        public decimal MonthlyPayment { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (Id < 0)
            {
                yield return new ValidationResult("Id can't be negative", new List<string> { "Id" });
            }
        }
    }
}