using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SD_LAB_03.Models
{
    /// <summary>
    /// Пасажирські поїзди
    /// </summary>
    public class PassengerTrains
    {
        //id рейса
        public int Id { get; set; }
        // Назва рейсу
        public string FlightName { get; set; }
        // модель транспортного засобу
        public string TrainModel { get; set; }
        //Кількість людей
        public int NumberPeople { get; set; }
        //public decimal MonthlyPayment { get; set; }
    }
}
