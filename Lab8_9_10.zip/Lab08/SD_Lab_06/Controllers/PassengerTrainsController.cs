﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SD_LAB_03.Models;
using SD_Lab_06.Models;

namespace SD_Lab_06.Controllers
{

    public class PassengerTrainsController : Controller
    {
        private readonly PassengerTrainsContext _context;

        public PassengerTrainsController(PassengerTrainsContext context)
        {
            _context = context;
        }

        // GET: PassengerTrains
        public async Task<IActionResult> Index()
        {
            return View(await _context.PassengerTrains.ToListAsync());
        }

        // GET: PassengerTrains/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var passengerTrains = await _context.PassengerTrains
                .SingleOrDefaultAsync(m => m.Id == id);
            if (passengerTrains == null)
            {
                return NotFound();
            }

            return View(passengerTrains);
        }

        // GET: PassengerTrains/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: PassengerTrains/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,FlightName,TrainModel,NumberPeople")] PassengerTrains passengerTrains)
        {
            if (ModelState.IsValid)
            {
                _context.Add(passengerTrains);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(passengerTrains);
        }

        // GET: PassengerTrains/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var passengerTrains = await _context.PassengerTrains.SingleOrDefaultAsync(m => m.Id == id);
            if (passengerTrains == null)
            {
                return NotFound();
            }
            return View(passengerTrains);
        }

        // POST: PassengerTrains/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,FlightName,TrainModel,NumberPeople")] PassengerTrains passengerTrains)
        {
            if (id != passengerTrains.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(passengerTrains);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PassengerTrainsExists(passengerTrains.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(passengerTrains);
        }

        // GET: PassengerTrains/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var passengerTrains = await _context.PassengerTrains
                .SingleOrDefaultAsync(m => m.Id == id);
            if (passengerTrains == null)
            {
                return NotFound();
            }

            return View(passengerTrains);
        }

        // POST: PassengerTrains/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var passengerTrains = await _context.PassengerTrains.SingleOrDefaultAsync(m => m.Id == id);
            _context.PassengerTrains.Remove(passengerTrains);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool PassengerTrainsExists(int id)
        {
            return _context.PassengerTrains.Any(e => e.Id == id);
        }
    }
}
