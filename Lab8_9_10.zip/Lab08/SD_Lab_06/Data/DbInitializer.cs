﻿using SD_Lab_06.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SD_Lab_06.Data
{
    public class DbInitializer
    {
        public static void Initialize(LabDbContext context)
        {
            //create database schema if none exists
            context.Database.EnsureCreated();

            if (context.RentAgreement.Any()) return;

            for (int i = 1; i < 11; i++)
            {
                context.RentAgreement.Add(
                new RentAgreement
                {
                    Id = i,
                    ClientName = Faker.Name.FullName(Faker.NameFormats.Standard),
                    Address = Faker.Address.StreetAddress(),
                    LeaseTerm = Faker.RandomNumber.Next(3, 36),
                    MonthlyPayment = Faker.RandomNumber.Next(1000, 3000)
                });
            }
            context.SaveChanges();
        }

    }
}
