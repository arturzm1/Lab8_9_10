﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace SD_Lab_06.Models
{
    public class LabDbContext : DbContext
    {
        public LabDbContext (DbContextOptions<LabDbContext> options)
            : base(options)
        {
        }

        public DbSet<SD_Lab_06.Models.RentAgreement> RentAgreement { get; set; }
    }
}