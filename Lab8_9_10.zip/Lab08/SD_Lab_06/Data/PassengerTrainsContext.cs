﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using SD_LAB_03.Models;

namespace SD_Lab_06.Models
{
    public class PassengerTrainsContext : DbContext
    {
        public PassengerTrainsContext (DbContextOptions<PassengerTrainsContext> options)
            : base(options)
        {
        }

        public DbSet<SD_LAB_03.Models.PassengerTrains> PassengerTrains { get; set; }
    }
}
