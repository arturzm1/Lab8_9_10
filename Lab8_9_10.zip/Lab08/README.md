# SD-Lab-04-Start

Software Design Lab 04 Start Code

Мета: Ознайомитися із принципом роботи архітектурного шаблону Web API

Теоретичні відомості

Додатково до матеріалів лекції пропонуємо ознайомитись із такими ресурсами:
[Create a web API with ASP.NET Core and Visual Studio for Windows](https://docs.microsoft.com/en-us/aspnet/core/tutorials/first-web-api)

[Getting started with ASP.NET Core MVC and Entity Framework Core using Visual Studio](https://docs.microsoft.com/en-us/aspnet/core/data/ef-mvc/intro)

Завдання

1. Отримати доступ до репозиторію за [таким запрошенням.](https://classroom.github.com/a/ucVFX9Nt)
1. Розробити міні-застосунок, який відображає дані з однієї таблиці (не менше 5 полів) за варіантом.

Варіанти завдань:

* Andreychuk - Офісні крісла та стільці
* Boroday - Комплектуючі деталі ПК
* Bortnyak - Мобільні телефони
* Chubey - Журнали
* Furman - Викладачі
* Ilnitskiy - Продукти харчування
* Klimchuk - Ліки
* Kovtsun - Пасажирські поїзди
* Kozemko - Міжміські автобуси
* Matsyuk - Авіарейси
* OstashIvan  - Ноутбуки і комп'ютери
* Palyuh - Навчальні курси
* Pavlyuk - Маршрут міського автобусу
* Rykun - Кафе
* Shumilova - Книги
* Sukachuk - Музеї
* Sukhodolska -  Школи
* Tanaschuk - Студенти
* Tverdohlib - Будматеріали
* Wowk - Канцтовари
* Zalevskiy – Безалкогольні напої (соки, мін. вода)
